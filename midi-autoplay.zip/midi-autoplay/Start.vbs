' MIDI Autoplay - by wejjejxi
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
d = fso.GetParentFolderName(WScript.ScriptFullName)
Set f = fso.OpenTextFile(d & "\app.ps1", 1)
t = f.ReadAll
f.Close
If InStr(t, "by wejjejxi") = 0 Then
    MsgBox "Authorship data was removed or modified. The program will not start.", 16, "MIDI Autoplay"
    WScript.Quit
End If
sh.Run "powershell -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File """ & d & "\app.ps1""", 0, False
