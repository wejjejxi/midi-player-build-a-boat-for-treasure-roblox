# MIDI Autoplay - by wejjejxi
$ErrorActionPreference = "Stop"

$id = [Security.Principal.WindowsIdentity]::GetCurrent()
$pr = New-Object Security.Principal.WindowsPrincipal($id)
if (-not $pr.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell -Verb RunAs -WindowStyle Hidden -ArgumentList "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# ---- authorship (integrity-checked: the app refuses to run if it is altered) ----
$script:credit = "by wejjejxi"
$script:creditHash = "152e418cd87b0b38cc9b735e78d610a437000ed6b1929b6ec03e7e57e255a237"
function Test-Credit {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $hex = [BitConverter]::ToString($sha.ComputeHash([System.Text.Encoding]::UTF8.GetBytes([string]$script:credit))).Replace("-", "").ToLower()
    return ($hex -eq $script:creditHash)
}
if (-not (Test-Credit)) {
    [System.Windows.Forms.MessageBox]::Show("Authorship data was modified. The program will not start.", "MIDI Autoplay") | Out-Null
    exit
}

Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class Input {
    [StructLayout(LayoutKind.Sequential)]
    public struct MOUSEINPUT {
        public int dx; public int dy; public uint mouseData;
        public uint dwFlags; public uint time; public UIntPtr dwExtraInfo;
    }
    [StructLayout(LayoutKind.Sequential)]
    public struct KEYBDINPUT {
        public ushort wVk; public ushort wScan;
        public uint dwFlags; public uint time; public UIntPtr dwExtraInfo;
    }
    [StructLayout(LayoutKind.Sequential)]
    public struct HARDWAREINPUT {
        public uint uMsg; public ushort wParamL; public ushort wParamH;
    }
    // MOUSEINPUT must be in the union so sizeof(INPUT) is correct (40 bytes on x64)
    [StructLayout(LayoutKind.Explicit)]
    public struct InputUnion {
        [FieldOffset(0)] public MOUSEINPUT mi;
        [FieldOffset(0)] public KEYBDINPUT ki;
        [FieldOffset(0)] public HARDWAREINPUT hi;
    }
    [StructLayout(LayoutKind.Sequential)]
    public struct INPUT {
        public uint type;
        public InputUnion u;
    }

    [DllImport("user32.dll", SetLastError = true)]
    static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);
    [DllImport("user32.dll")]
    public static extern short GetAsyncKeyState(int vKey);

    const uint INPUT_KEYBOARD = 1;
    const uint KEYEVENTF_KEYUP = 0x0002;
    const uint KEYEVENTF_SCANCODE = 0x0008;
    static readonly int cbSize = Marshal.SizeOf(typeof(INPUT));

    // Sends a hardware-style key event: wVk = 0, scan code only.
    // Returns the number of events injected (0 = failure).
    public static uint Key(ushort scan, bool up) {
        INPUT[] a = new INPUT[1];
        a[0].type = INPUT_KEYBOARD;
        a[0].u.ki.wVk = 0;
        a[0].u.ki.wScan = scan;
        a[0].u.ki.dwFlags = KEYEVENTF_SCANCODE | (up ? KEYEVENTF_KEYUP : 0u);
        a[0].u.ki.time = unchecked((uint)Environment.TickCount);
        a[0].u.ki.dwExtraInfo = UIntPtr.Zero;
        return SendInput(1, a, cbSize);
    }
}
"@

# ---- 12-key map: single octave, pitch class only (octave ignored) ----
# order matches the in-game note boards: F# G G# A A# B C C# D D# E F
$script:keyChars = @('e','r','t','y','u','k','l','p','[',']',';','''')
# Set 1 scan codes of the physical keys: E R T Y U K L P [ ] ; '
$script:keyScan  = @(0x12,0x13,0x14,0x15,0x16,0x25,0x26,0x19,0x1A,0x1B,0x27,0x28)
$script:sendFail = 0
$script:noteNamesOrdered = @('F#','G','G#','A','A#','B','C','C#','D','D#','E','F')

function Note-ToName($n) {
    $pc = (($n % 12) + 12) % 12
    $idx = ($pc + 6) % 12
    return $script:noteNamesOrdered[$idx]
}

function Note-ToKeyIndex($note) {
    $pc = (($note % 12) + 12) % 12
    return ($pc + 6) % 12
}

function Read-VarLen([byte[]]$b, [ref]$pos) {
    $value = 0
    do {
        $byte = $b[$pos.Value]; $pos.Value++
        $value = ($value * 128) + ($byte -band 0x7F)
    } while ($byte -band 0x80)
    return $value
}

$script:parseDebug = New-Object System.Collections.Generic.List[string]

function Parse-Midi($path) {
    $script:parseDebug.Clear()
    $b = [System.IO.File]::ReadAllBytes($path)
    if ($b.Length -lt 14 -or [System.Text.Encoding]::ASCII.GetString($b, 0, 4) -ne "MThd") {
        throw "Not a valid MIDI file."
    }
    $ntrks = ($b[10] * 256) + $b[11]
    $division = ($b[12] * 256) + $b[13]
    if ($division -band 0x8000) { $division = 480 }  # SMPTE time, fallback
    $script:parseDebug.Add("File size: $($b.Length) bytes, ntrks=$ntrks, division=$division")

    $pos = 14
    $noteEvents = New-Object System.Collections.Generic.List[object]
    $tempoEvents = New-Object System.Collections.Generic.List[object]

    for ($t = 0; $t -lt $ntrks; $t++) {
        if ($pos + 8 -gt $b.Length) { break }
        $chunkId = [System.Text.Encoding]::ASCII.GetString($b, $pos, 4)
        $len = [int64]0
        $len = ([int64]$b[$pos+4] * 16777216) + ([int64]$b[$pos+5] * 65536) + ([int64]$b[$pos+6] * 256) + [int64]$b[$pos+7]
        $pos += 8
        $script:parseDebug.Add("Track $t : chunkId='$chunkId' len=$len startPos=$pos")
        if ($chunkId -ne "MTrk") { $pos += $len; continue }

        $trackEnd = $pos + $len
        $absTick = 0
        $running = 0
        $evCount = 0

        while ($pos -lt $trackEnd) {
            $r = $pos
            $delta = Read-VarLen $b ([ref]$r)
            $pos = $r
            $absTick += $delta

            $status = [int]$b[$pos]
            if ($status -ge 0x80) { $running = $status; $pos++ } else { $status = $running }

            if ($evCount -lt 12) {
                $script:parseDebug.Add("  ev$evCount pos=$pos tick=$absTick status=0x$($status.ToString('X2'))")
            }

            if ($status -eq 0xFF) {
                $metaType = [int]$b[$pos]; $pos++
                $r = $pos
                $mlen = Read-VarLen $b ([ref]$r)
                $pos = $r
                if ($metaType -eq 0x51 -and $mlen -eq 3) {
                    $us = ([int]$b[$pos] -shl 16) -bor ([int]$b[$pos+1] -shl 8) -bor [int]$b[$pos+2]
                    $tempoEvents.Add(@{ tick = $absTick; us = $us })
                }
                $pos += $mlen
            } elseif ($status -eq 0xF0 -or $status -eq 0xF7) {
                $r = $pos
                $slen = Read-VarLen $b ([ref]$r)
                $pos = $r + $slen
            } elseif ($status -lt 0x80) {
                $script:parseDebug.Add("  ABORT: bad status $status at pos=$pos (no running status set)")
                $pos = $trackEnd
            } else {
                $hi = $status -band 0xF0
                switch ($hi) {
                    0x80 { $note = [int]$b[$pos]; $pos += 2; $noteEvents.Add(@{ tick = $absTick; type = 'off'; note = $note }) }
                    0x90 { $note = [int]$b[$pos]; $vel = [int]$b[$pos+1]; $pos += 2
                           if ($vel -eq 0) { $noteEvents.Add(@{ tick = $absTick; type = 'off'; note = $note }) }
                           else { $noteEvents.Add(@{ tick = $absTick; type = 'on'; note = $note }) } }
                    0xA0 { $pos += 2 }
                    0xB0 { $pos += 2 }
                    0xC0 { $pos += 1 }
                    0xD0 { $pos += 1 }
                    0xE0 { $pos += 2 }
                    default {
                        $script:parseDebug.Add("  ABORT: unknown status 0x$($status.ToString('X2')) (hi=0x$($hi.ToString('X2'))) at pos=$pos")
                        $pos = $trackEnd
                    }
                }
            }
            $evCount++
        }
        $script:parseDebug.Add("Track $t finished: pos=$pos trackEnd=$trackEnd events=$evCount notesSoFar=$($noteEvents.Count)")
        $pos = $trackEnd
    }

    $tempoEvents = @($tempoEvents | Sort-Object { [int]$_.tick })
    if ($tempoEvents.Count -eq 0 -or [int]$tempoEvents[0].tick -ne 0) {
        $tempoEvents = @(@{ tick = 0; us = 500000 }) + $tempoEvents
    }

    $noteList = @($noteEvents | Sort-Object { [int]$_.tick })
    $divisionD = [double]$division

    $curUs = 500000.0
    $curMs = 0.0
    $curTick = 0
    $ti = 0
    $tCount = $tempoEvents.Count

    $result = New-Object System.Collections.Generic.List[object]
    foreach ($ev in $noteList) {
        $target = [int]$ev.tick
        while (($ti -lt $tCount) -and ([int]$tempoEvents[$ti].tick -le $target)) {
            $tt = [int]$tempoEvents[$ti].tick
            $curMs += ($tt - $curTick) * $curUs / $divisionD / 1000.0
            $curTick = $tt
            $curUs = [double]$tempoEvents[$ti].us
            $ti++
        }
        $curMs += ($target - $curTick) * $curUs / $divisionD / 1000.0
        $curTick = $target
        $result.Add(@{ ms = [double]$curMs; type = $ev.type; note = [int]$ev.note })
    }

    $order = @{ 'off' = 0; 'on' = 1 }
    return @($result | Sort-Object @{Expression = { [double]$_.ms } }, @{Expression = { $order[$_.type] } })
}

# ---- playback ----
$script:stopFlag = $false
$script:playing = $false

function Press($sc) {
    if ([Input]::Key([uint16]$sc, $false) -eq 0) { $script:sendFail++ }
}
function Release($sc) {
    if ([Input]::Key([uint16]$sc, $true) -eq 0) { $script:sendFail++ }
}

function Wait-Pump([int]$ms) {
    $deadline = [Environment]::TickCount + $ms
    while ([Environment]::TickCount -lt $deadline) {
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 2
    }
}

function Log($text) {
    if ($script:form.InvokeRequired) {
        $script:form.Invoke([Action]{ $script:logBox.AppendText($text + "`r`n") })
    } else {
        $script:logBox.AppendText($text + "`r`n")
    }
}

function Set-StatusText($text) {
    if ($script:form.InvokeRequired) {
        $script:form.Invoke([Action]{ $script:lblStatus.Text = $text })
    } else {
        $script:lblStatus.Text = $text
    }
}

function Play-Midi($events, $speed) {
    $script:stopFlag = $false
    $script:playing = $true
    $held = @{}
    $script:sendFail = 0
    $skipped = 0
    $sent = 0

    Log ("MIDI Autoplay " + $script:credit)
    Log "Starting in 3..."
    for ($i = 3; $i -ge 1; $i--) {
        Set-StatusText "Starting in $i..."
        Wait-Pump 1000
        if ($script:stopFlag) { $script:playing = $false; Set-StatusText "Stopped"; return }
    }
    Set-StatusText "Playing..."

    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $total = $events.Count
    $i = 0

    foreach ($ev in $events) {
        $i++
        if (([int]([Input]::GetAsyncKeyState(0x77)) -band 0x8000) -ne 0) { $script:stopFlag = $true }
        if ($script:stopFlag) { break }

        $targetMs = [double]$ev.ms / $speed
        while ($sw.Elapsed.TotalMilliseconds -lt $targetMs) {
            if (([int]([Input]::GetAsyncKeyState(0x77)) -band 0x8000) -ne 0) { $script:stopFlag = $true; break }
            [System.Windows.Forms.Application]::DoEvents()
            Start-Sleep -Milliseconds 3
        }
        if ($script:stopFlag) { break }

        $idx = Note-ToKeyIndex $ev.note
        if ($idx -lt 0) { $skipped++; continue }
        $sc = $script:keyScan[$idx]

        if ($ev.type -eq 'on') {
            if ($held.ContainsKey($idx)) { Release $sc }
            Press $sc
            $held[$idx] = $true
            $sent++
        } else {
            if ($held.ContainsKey($idx)) { Release $sc; $held.Remove($idx) }
        }

        if ($i % 40 -eq 0) { Set-StatusText ("Playing... " + [int](100 * $i / $total) + "%") }
    }

    foreach ($idx in @($held.Keys)) { Release $script:keyScan[$idx] }

    if ($script:stopFlag) { Log "Stopped."; Set-StatusText "Stopped" }
    else { Log "Finished."; Set-StatusText "Finished" }
    Log ("Key presses sent: " + $sent + "   Notes skipped (out of range): " + $skipped)
    if ($script:sendFail -gt 0) { Log ("WARNING: SendInput failed " + $script:sendFail + " times (blocked by UIPI / game running as higher privilege?)") }
    Log ("-- MIDI Autoplay " + $script:credit + " --")
    $script:playing = $false
}

# ---- UI ----
$script:fontMain = New-Object System.Drawing.Font("Segoe UI", 10.5)
$blue = [System.Drawing.Color]::FromArgb(0, 120, 215)

function New-Button($text, $x, $y, $w, $h, $primary) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $text
    $b.Location = New-Object System.Drawing.Point($x, $y)
    $b.Size = New-Object System.Drawing.Size($w, $h)
    $b.Font = $script:fontMain
    $b.FlatStyle = "Flat"
    $b.Cursor = [System.Windows.Forms.Cursors]::Hand
    if ($primary) {
        $b.BackColor = $blue; $b.ForeColor = [System.Drawing.Color]::White
        $b.FlatAppearance.BorderSize = 0
    } else {
        $b.BackColor = [System.Drawing.Color]::White
        $b.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(190,190,190)
    }
    return $b
}

$script:form = New-Object System.Windows.Forms.Form
$form = $script:form
$form.Text = "MIDI Autoplay - " + $script:credit
$form.ClientSize = New-Object System.Drawing.Size(440, 448)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $false
$form.BackColor = [System.Drawing.Color]::FromArgb(245,245,245)
$form.Font = $script:fontMain

$lblFile = New-Object System.Windows.Forms.Label
$lblFile.Text = "No file selected"
$lblFile.Location = New-Object System.Drawing.Point(15, 20)
$lblFile.Size = New-Object System.Drawing.Size(410, 22)
$lblFile.ForeColor = [System.Drawing.Color]::FromArgb(90,90,90)
$form.Controls.Add($lblFile)

$btnBrowse = New-Button "Select MIDI file" 15 48 410 42 $true
$form.Controls.Add($btnBrowse)

$lblSpeed = New-Object System.Windows.Forms.Label
$lblSpeed.Text = "Speed:"
$lblSpeed.Location = New-Object System.Drawing.Point(15, 108)
$lblSpeed.Size = New-Object System.Drawing.Size(60, 30)
$form.Controls.Add($lblSpeed)

$numSpeed = New-Object System.Windows.Forms.NumericUpDown
$numSpeed.DecimalPlaces = 2
$numSpeed.Increment = 0.05
$numSpeed.Minimum = 0.25
$numSpeed.Maximum = 3
$numSpeed.Value = 1.0
$numSpeed.Location = New-Object System.Drawing.Point(80, 106)
$numSpeed.Size = New-Object System.Drawing.Size(80, 30)
$numSpeed.Font = $script:fontMain
$form.Controls.Add($numSpeed)

$lblTranspose = New-Object System.Windows.Forms.Label
$lblTranspose.Text = "Transpose:"
$lblTranspose.Location = New-Object System.Drawing.Point(180, 108)
$lblTranspose.Size = New-Object System.Drawing.Size(80, 30)
$form.Controls.Add($lblTranspose)

$numTranspose = New-Object System.Windows.Forms.NumericUpDown
$numTranspose.Minimum = -24
$numTranspose.Maximum = 24
$numTranspose.Value = 0
$numTranspose.Location = New-Object System.Drawing.Point(260, 106)
$numTranspose.Size = New-Object System.Drawing.Size(70, 30)
$numTranspose.Font = $script:fontMain
$form.Controls.Add($numTranspose)

$btnPlay = New-Button "Play" 15 150 195 42 $true
$btnStop = New-Button "Stop (F8)" 230 150 195 42 $false
$form.Controls.Add($btnPlay)
$form.Controls.Add($btnStop)

$btnKeymap = New-Button "Show key map" 15 202 410 36 $false
$form.Controls.Add($btnKeymap)

$lblStatus = New-Object System.Windows.Forms.Label
$lblStatus.Text = "Idle"
$lblStatus.Location = New-Object System.Drawing.Point(15, 248)
$lblStatus.Size = New-Object System.Drawing.Size(410, 24)
$lblStatus.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 10.5)
$form.Controls.Add($lblStatus)
$script:lblStatus = $lblStatus

$logBox = New-Object System.Windows.Forms.TextBox
$logBox.Multiline = $true
$logBox.ReadOnly = $true
$logBox.ScrollBars = "Vertical"
$logBox.Font = New-Object System.Drawing.Font("Consolas", 9.5)
$logBox.Location = New-Object System.Drawing.Point(15, 276)
$logBox.Size = New-Object System.Drawing.Size(410, 128)
$form.Controls.Add($logBox)
$script:logBox = $logBox

$lblCredit = New-Object System.Windows.Forms.Label
$lblCredit.Text = "MIDI Autoplay " + $script:credit
$lblCredit.Location = New-Object System.Drawing.Point(15, 414)
$lblCredit.Size = New-Object System.Drawing.Size(410, 22)
$lblCredit.TextAlign = "MiddleRight"
$lblCredit.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9.5)
$lblCredit.ForeColor = [System.Drawing.Color]::FromArgb(110,110,110)
$form.Controls.Add($lblCredit)

$script:midiPath = $null
$script:parsedEvents = $null

$btnBrowse.Add_Click({
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Filter = "MIDI files (*.mid;*.midi)|*.mid;*.midi|All files (*.*)|*.*"
    if ($dlg.ShowDialog() -eq "OK") {
        $script:midiPath = $dlg.FileName
        $lblFile.Text = [System.IO.Path]::GetFileName($script:midiPath)
        try {
            $script:parsedEvents = Parse-Midi $script:midiPath
            $onCount = ($script:parsedEvents | Where-Object { $_.type -eq 'on' }).Count
            $durSec = 0
            if ($script:parsedEvents.Count -gt 0) {
                $durSec = [double]$script:parsedEvents[$script:parsedEvents.Count - 1].ms / 1000.0
            }
            Log ("Loaded: " + $lblFile.Text + " - " + $onCount + " notes, " + $script:parsedEvents.Count + " events total")
            Log ("Song duration: " + [math]::Round($durSec, 1) + " sec")
            foreach ($d in $script:parseDebug) { Log ("  [debug] " + $d) }
            $lblStatus.Text = "Ready"
        } catch {
            Log ("Error reading file: " + $_.Exception.Message)
            $script:parsedEvents = $null
        }
    }
})

$btnPlay.Add_Click({
    if (-not (Test-Credit)) { Log "Authorship data was modified."; return }
    if ($script:playing) { Log "Already playing."; return }
    if (-not $script:parsedEvents) { Log "Select a MIDI file first."; return }

    $events = $script:parsedEvents
    $shift = [int]$numTranspose.Value
    if ($shift -ne 0) {
        $events = $events | ForEach-Object { @{ ms = $_.ms; type = $_.type; note = $_.note + $shift } }
    }
    $speed = [double]$numSpeed.Value

    $btnPlay.Enabled = $false
    $btnBrowse.Enabled = $false
    try {
        Play-Midi $events $speed
    } finally {
        $btnPlay.Enabled = $true
        $btnBrowse.Enabled = $true
    }
})

$btnStop.Add_Click({ $script:stopFlag = $true })

$btnKeymap.Add_Click({
    $lines = New-Object System.Collections.Generic.List[string]
    for ($i = 0; $i -lt 12; $i++) {
        $lines.Add($script:noteNamesOrdered[$i] + "  ->  " + $script:keyChars[$i])
    }
    $lines.Add("")
    $lines.Add("MIDI Autoplay " + $script:credit)
    $mapForm = New-Object System.Windows.Forms.Form
    $mapForm.Text = "Key map - " + $script:credit
    $mapForm.ClientSize = New-Object System.Drawing.Size(220, 260)
    $mapForm.StartPosition = "CenterParent"
    $mapForm.FormBorderStyle = "FixedDialog"
    $mapForm.MaximizeBox = $false
    $box = New-Object System.Windows.Forms.TextBox
    $box.Multiline = $true
    $box.ReadOnly = $true
    $box.ScrollBars = "Vertical"
    $box.Font = New-Object System.Drawing.Font("Consolas", 10)
    $box.Dock = "Fill"
    $box.Text = ($lines -join "`r`n")
    $mapForm.Controls.Add($box)
    $mapForm.ShowDialog($form) | Out-Null
})

$form.Add_FormClosing({ $script:stopFlag = $true })

Log ("MIDI Autoplay " + $script:credit)
Log "Select a MIDI file to begin. Press F8 any time to stop playback."
[void]$form.ShowDialog()
